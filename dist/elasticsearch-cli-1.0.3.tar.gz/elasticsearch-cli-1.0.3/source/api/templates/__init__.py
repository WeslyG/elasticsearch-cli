from .templates import get_templates
from .templates import delete_templates


__all__ = [get_templates, delete_templates]
