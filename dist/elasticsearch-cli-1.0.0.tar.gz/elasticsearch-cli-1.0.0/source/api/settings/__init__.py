from .settings import get_settings
from .settings import set_config


__all__ = [get_settings, set_config]
