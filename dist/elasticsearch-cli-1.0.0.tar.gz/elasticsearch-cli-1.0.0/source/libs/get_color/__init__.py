from .get_color import get_color

__all__ = [get_color]
