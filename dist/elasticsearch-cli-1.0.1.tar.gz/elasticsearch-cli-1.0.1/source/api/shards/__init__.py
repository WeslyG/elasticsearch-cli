from .shards import get_shards

__all__ = [get_shards]
